package com.example.constitutionofindia

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.cardview.widget.CardView
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.IndiaCanon.constitutionofindia.R
import com.example.constitutionofindia.amendments.Activity_Amendmentslist
import com.example.constitutionofindia.parts.Activity_Partslist
import com.example.constitutionofindia.preamble.Activity_Preamble
import com.example.constitutionofindia.schedules.Activity_Scheduleslist
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import com.google.android.material.navigation.NavigationView

class Activity_Main : AppCompatActivity() , View.OnClickListener{


    lateinit var Activity_Main_BannerAd : AdView
    lateinit var toggle: ActionBarDrawerToggle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        MobileAds.initialize(this){}
        val Activity_Main_BannerAdRequest = AdRequest.Builder().build()

        Activity_Main_BannerAd = findViewById(R.id.activity_main_adView)
        Activity_Main_BannerAd.loadAd(Activity_Main_BannerAdRequest)

        toggle = ActionBarDrawerToggle(this, findViewById(R.id.activity_main_drawer), findViewById(R.id.activity_main_tb), R.string.menu, R.string.menu_close)
        findViewById<DrawerLayout>(R.id.activity_main_drawer).addDrawerListener(toggle)
        toggle.syncState()

        setSupportActionBar(findViewById(R.id.activity_main_tb))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)


        findViewById<CardView>(R.id.activity_main_cvPreamble).setOnClickListener(this)
        findViewById<CardView>(R.id.activity_main_cvParts).setOnClickListener(this)
        findViewById<CardView>(R.id.activity_main_cvSchedules).setOnClickListener(this)
        findViewById<CardView>(R.id.activity_main_cvAmendments).setOnClickListener(this)

        findViewById<NavigationView>(R.id.activity_main_drawer_navView).setNavigationItemSelectedListener {
            when(it.itemId){
                R.id.main_menu_Settings -> {
                    Intent(this, Activity_Settings::class.java).also {
                        startActivity(it)
                    }
                }
                R.id.main_menu_FAQs -> {
                    Toast.makeText(this, R.string.app_name, Toast.LENGTH_SHORT).show()
                }
                R.id.main_menu_About -> {
                    Toast.makeText(this, R.string.app_name, Toast.LENGTH_SHORT).show()
                }
                R.id.main_menu_Share -> {
                    Toast.makeText(this, R.string.app_name, Toast.LENGTH_SHORT).show()
                }
                R.id.main_menu_rate -> {
                    Toast.makeText(this, R.string.app_name, Toast.LENGTH_SHORT).show()
                }
            }

            findViewById<DrawerLayout>(R.id.activity_main_drawer).also { drawer ->
                drawer.closeDrawer(GravityCompat.START)
            }
            true
        }





    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if(toggle.onOptionsItemSelected(item)){
            return true
        }

        return super.onOptionsItemSelected(item)
    }


    override fun onClick(view: View?) {

        when(view!!.id){

            R.id.activity_main_cvPreamble -> {
                Intent(this, Activity_Preamble::class.java).also {
                    startActivity(it)
                }
            }

            R.id.activity_main_cvParts -> {
                Intent(this, Activity_Partslist::class.java).also {
                    startActivity(it)
                }
            }
            R.id.activity_main_cvSchedules -> {
                Intent(this, Activity_Scheduleslist::class.java).also {
                    startActivity(it)
                }
            }
            R.id.activity_main_cvAmendments -> {
                Intent(this, Activity_Amendmentslist::class.java).also {
                    startActivity(it)
                }
            }


        }
    }
}
