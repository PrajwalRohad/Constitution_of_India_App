package com.example.constitutionofindia.schedules

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Html
import android.widget.TextView
import com.IndiaCanon.constitutionofindia.R
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import org.json.JSONObject

class Activity_Schedule : AppCompatActivity() {
    lateinit var Activity_Schedule_BannerAd : AdView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_schedule)

        MobileAds.initialize(this){}
        val Activity_Schedule_BannerAdRequest = AdRequest.Builder().build()

        Activity_Schedule_BannerAd = findViewById(R.id.activity_schedule_adView)
        Activity_Schedule_BannerAd.loadAd(Activity_Schedule_BannerAdRequest)

        val name : String?

        intent.extras.also {
            name = it?.getString("scheduleName")
        }

        val jschedulefile : String = applicationContext.assets.open("schedules.json").bufferedReader().use {
            it.readText()
        }

        val jscheduleobj = JSONObject(jschedulefile)
        val schedulenum = jscheduleobj.getJSONObject(name).getString("num")
        val schedulename = jscheduleobj.getJSONObject(name).getString("name")
        val scheduletext = jscheduleobj.getJSONObject(name).getString("text")
        val scheduleArt = jscheduleobj.getJSONObject(name).getString("articlesRelated")
        val schedulefootnote = jscheduleobj.getJSONObject(name).getString("footnote")






        findViewById<TextView>(R.id.activity_schedule_cvtvHeadline).also {
            it.setText(Html.fromHtml(schedulenum+"<br></br>"+schedulename, Html.FROM_HTML_MODE_LEGACY))
        }
        findViewById<TextView>(R.id.activity_schedule_cvtvArticlesNum).also {
            it.setText(Html.fromHtml(scheduleArt, Html.FROM_HTML_MODE_LEGACY))
        }
        findViewById<TextView>(R.id.activity_schedule_tvtext).also {
           it.setText(Html.fromHtml(scheduletext, Html.FROM_HTML_MODE_LEGACY))
        }
        findViewById<TextView>(R.id.activity_schedule_tvfootnote).also {
            it.setText(Html.fromHtml(schedulefootnote, Html.FROM_HTML_MODE_LEGACY))
        }


    }
}