package com.example.constitutionofindia.parts

data class Element_Partslist(
    val PartNum : String,
    val PartName : String,
    val PartRange : String
)