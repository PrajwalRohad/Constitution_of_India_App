package com.example.constitutionofindia.articles

data class Element_Articleslist(
    val ArticleNum : String,
    val ArticleName : String
)