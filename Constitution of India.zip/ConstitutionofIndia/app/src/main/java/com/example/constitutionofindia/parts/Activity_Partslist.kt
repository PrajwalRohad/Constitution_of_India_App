package com.example.constitutionofindia.parts

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.IndiaCanon.constitutionofindia.R
import com.example.constitutionofindia.articles.Activity_Articleslist
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import org.json.JSONArray
import org.json.JSONObject

class Activity_Partslist : AppCompatActivity(),
Adapter_Partslist.PartsListInterface    {
    lateinit var Activity_Partslist_BannerAd : AdView
    lateinit var keysparts : JSONArray

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_partslist)

        MobileAds.initialize(this){}
        val Activity_Partslist_BannerAdRequest = AdRequest.Builder().build()

        Activity_Partslist_BannerAd = findViewById(R.id.activity_partslist_adView)
        Activity_Partslist_BannerAd.loadAd(Activity_Partslist_BannerAdRequest)


//        val partTitlesArray = resources.getStringArray(R.array.PartTitles)
//        val partNamesArray  = resources.getStringArray(R.array.PartNames)
//        val partRangesArray = resources.getStringArray(R.array.PartRanges)

        val partItemslist = mutableListOf<Element_Partslist>()

        val jpartsfile = applicationContext.assets.open("parts.json").bufferedReader().use {
            it.readText()
        }
        val jpartobj = JSONObject(jpartsfile)
        keysparts = jpartobj.names()


        for(i in 0 .. keysparts.length()-1){
            val num = jpartobj.getJSONObject(keysparts[i].toString()).getString("part_num")
            val name = jpartobj.getJSONObject(keysparts[i].toString()).getString("part_name")
            val range = jpartobj.getJSONObject(keysparts[i].toString()).getString("range")
            partItemslist.add(Element_Partslist(num, name, "Articles\n"+range))
//            partItemslist.add(Element_Partslist(partTitlesArray[i], partNamesArray[i], "Articles\n"+partRangesArray[i]))
        }

        val partslistAdapter = Adapter_Partslist(partItemslist, this)
        findViewById<RecyclerView>(R.id.activity_partslist_rvPartslist).also {
            it.adapter = partslistAdapter
            it.layoutManager = LinearLayoutManager(this)
            it.addItemDecoration(DividerItemDecoration(this, LinearLayoutManager.VERTICAL))
        }





    }

    override fun PartOnClick(position: Int) {
//        Toast.makeText(this, "clicked "+position, Toast.LENGTH_LONG).show()

        Intent(this, Activity_Articleslist::class.java).also {
            it.putExtra("partNum", keysparts[position].toString())
            startActivity(it)
        }
    }
}