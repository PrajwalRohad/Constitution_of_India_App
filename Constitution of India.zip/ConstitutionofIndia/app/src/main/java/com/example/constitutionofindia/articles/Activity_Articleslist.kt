package com.example.constitutionofindia.articles

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.IndiaCanon.constitutionofindia.R
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import org.json.JSONArray
import org.json.JSONObject

class Activity_Articleslist : AppCompatActivity(), Adapter_Articleslist.ArticlesListInterface {
    lateinit var Activity_Articleslist_BannerAd : AdView

//    lateinit var articleNumArray : Array<String>
//    lateinit var articleNameArray : Array<String>

    lateinit var partNum : String
    lateinit var partName : String

    lateinit var chapterNumList : MutableList<String>
    lateinit var chapterNameList : MutableList<String>

    lateinit var sectionsNameList : MutableList<String>

    lateinit var articlesNumList : MutableList<String>
    lateinit var articlesNameList : MutableList<String>
    lateinit var articlesTextList : MutableList<String>
    lateinit var articlesFootnoteList : MutableList<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_articleslist)

        MobileAds.initialize(this){}
        val Activity_Articleslist_BannerAdRequest = AdRequest.Builder().build()

        Activity_Articleslist_BannerAd = findViewById(R.id.activity_articleslist_adView)
        Activity_Articleslist_BannerAd.loadAd(Activity_Articleslist_BannerAdRequest)


//        articleNumArray = resources.getStringArray(R.array.ArticleNum)
//        articleNameArray = resources.getStringArray(R.array.ArticleName)

        val partNumKey : String?

        intent.extras.also {
            partNumKey = it?.getString("partNum")
        }

        val jpartsfile = applicationContext.assets.open("parts.json").bufferedReader().use {
            it.readText()
        }
        val jpartsobj = JSONObject(jpartsfile)
        val partobj = jpartsobj.getJSONObject(partNumKey)
        partNum = partobj.getString("part_num")
        partName = partobj.getString("part_name")

        val chaptersList = partobj.getJSONArray("chapters")
        var sectionsList : JSONArray


        chapterNumList = mutableListOf()
        chapterNameList = mutableListOf()
        sectionsNameList = mutableListOf()
        articlesNumList = mutableListOf()
        articlesNameList = mutableListOf()
        articlesTextList = mutableListOf()
        articlesFootnoteList = mutableListOf()




//        Log.d("Article123", "chapters are -"+chaptersList)
//        Log.d("Article123", "chapters type -"+chaptersList.javaClass)
//        Log.d("Article123", "first chapter name is -"+chaptersList[0])
//        Log.d("Article123", "first chapter name is -"+chaptersList[0].toString())

        for(i in 0..chaptersList.length()-1){
            val chapter = partobj.getJSONObject(chaptersList[i].toString())
//            Log.d("Article123", "chapter is -"+chapter)
            sectionsList = chapter.getJSONArray("sections")
//            Log.d("Article123", "sections are -"+sectionsList)
//
            for(j in 0..sectionsList.length()-1){
                val section = chapter.getJSONObject(sectionsList[j].toString())

                val articles = section.getJSONArray("articles")
                for(k in 0..articles.length()-1){
                    chapterNumList.add(chapter.getString("chapter_num"))
                    chapterNameList.add(chapter.getString("chapter_name"))

                    sectionsNameList.add(section.getString("section_name").toString())

                    articlesNumList.add(articles.getJSONObject(k).getString("num"))
                    articlesNameList.add(articles.getJSONObject(k).getString("name"))
                    articlesTextList.add(articles.getJSONObject(k).getString("text"))
                    articlesFootnoteList.add(articles.getJSONObject(k).getString("footnote"))

                }
            }
        }




        val articleItemList = mutableListOf<Element_Articleslist>()

        for(i in articlesNumList.indices){
            articleItemList.add(Element_Articleslist(articlesNumList[i], articlesNameList[i]))
        }
//        for(i in articleNumArray.indices){
//            articleItemList.add(Element_Articleslist(articleNumArray[i], articleNameArray[i]))
//        }

        val articlesListAdapter = Adapter_Articleslist(articleItemList, this)

        findViewById<RecyclerView>(R.id.activity_articleslist_rvArticleslist).also {
            it.adapter = articlesListAdapter
            it.layoutManager = LinearLayoutManager(this)
            it.addItemDecoration(DividerItemDecoration(this, LinearLayoutManager.VERTICAL))
        }


    }

    override fun ArticleOnClick(position: Int) {
        Intent(this, Activity_Article::class.java).also {
            it.putExtra("partNum", partNum)
            it.putExtra("partName", partName)
            it.putExtra("chapterNum", chapterNumList[position])
            it.putExtra("chapterName", chapterNameList[position])
            it.putExtra("sectionName", sectionsNameList[position])
            it.putExtra("articlesNum", articlesNumList[position])
            it.putExtra("articlesName", articlesNameList[position])
            it.putExtra("articlesText", articlesTextList[position])
            it.putExtra("articlesFootnote", articlesFootnoteList[position])
            startActivity(it)
        }
    }
}