package com.example.constitutionofindia.amendments

data class Element_Amendmentslist(
    val AmendmentName : String,
    val AmendmentYear: String
)