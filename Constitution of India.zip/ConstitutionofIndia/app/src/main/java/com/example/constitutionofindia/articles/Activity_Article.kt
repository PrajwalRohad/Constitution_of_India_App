package com.example.constitutionofindia.articles

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Html
import android.view.View
import android.widget.TextView
import androidx.core.view.marginBottom
import com.IndiaCanon.constitutionofindia.R
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds

class Activity_Article : AppCompatActivity() {
    lateinit var Activity_Article_BannerAd : AdView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_article)

        val partNum: String?
        val partName: String?
        val chapterNum: String?
        val chapterName: String?
        val sectionName: String?
        val articlesNum: String?
        val articlesName: String?
        val articlesText: String?
        val articlesFootnote: String?

        intent.extras.also {
            partNum = it?.getString("partNum")
            partName = it?.getString("partName")
            chapterNum = it?.getString("chapterNum")
            chapterName = it?.getString("chapterName")
            sectionName = it?.getString("sectionName")
            articlesNum = it?.getString("articlesNum")
            articlesName = it?.getString("articlesName")
            articlesText = it?.getString("articlesText")
            articlesFootnote = it?.getString("articlesFootnote")
        }

        MobileAds.initialize(this){}
        val Activity_Article_BannerAdRequest = AdRequest.Builder().build()

        Activity_Article_BannerAd = findViewById(R.id.activity_article_adView)
        Activity_Article_BannerAd.loadAd(Activity_Article_BannerAdRequest)

        findViewById<TextView>(R.id.activity_article_tvHeadline).also {
            it.setText(Html.fromHtml(articlesNum+"<br></br>"+articlesName, Html.FROM_HTML_MODE_LEGACY))
        }

        findViewById<TextView>(R.id.activity_article_tvPartNum).also {
//            if(partNum.equals("null")){
//                it.visibility = View.GONE
//            }else{
//                it.setText(partNum)
//            }
            it.setText(Html.fromHtml(partNum, Html.FROM_HTML_MODE_LEGACY))
        }

        findViewById<TextView>(R.id.activity_article_tvPartName).also {
//            if(partName.equals("null")){
//                it.visibility = View.GONE
//            }else{
//                it.setText(partName)
//            }
            it.setText(Html.fromHtml(partName, Html.FROM_HTML_MODE_LEGACY))
        }

        findViewById<TextView>(R.id.activity_article_tvChapterNum).also {
            if(chapterNum.equals("null")){
                it.visibility = View.GONE

            }else{
                it.setText(Html.fromHtml(chapterNum, Html.FROM_HTML_MODE_LEGACY))
            }
        }

        findViewById<TextView>(R.id.activity_article_tvChapterName).also {
            if(chapterName.equals("null")){
                it.visibility = View.GONE
            }else{
                it.setText(Html.fromHtml(chapterName, Html.FROM_HTML_MODE_LEGACY))
            }
        }

        findViewById<TextView>(R.id.activity_article_tvSubSection).also {
            if(sectionName.equals("null")){
                it.visibility = View.GONE
            }else{
                it.setText(Html.fromHtml(sectionName, Html.FROM_HTML_MODE_LEGACY))
            }
        }

        findViewById<TextView>(R.id.activity_article_tvtext).also {
            it.setText(Html.fromHtml(articlesText, Html.FROM_HTML_MODE_LEGACY))
        }

        findViewById<TextView>(R.id.activity_article_tvfootnote).also {

            if(articlesFootnote.equals("null")){
                it.visibility = View.GONE
            }else{
                it.setText(Html.fromHtml(articlesFootnote, Html.FROM_HTML_MODE_LEGACY))
            }

        }


    }
}



















