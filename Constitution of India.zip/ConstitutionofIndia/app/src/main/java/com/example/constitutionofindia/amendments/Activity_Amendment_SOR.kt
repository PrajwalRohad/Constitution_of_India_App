package com.example.constitutionofindia.amendments

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Html
import android.widget.TextView
import com.IndiaCanon.constitutionofindia.R
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds

class Activity_Amendment_SOR : AppCompatActivity() {
    lateinit var Activity_Amendment_SOR_BannerAd : AdView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_amendment_sor)

        MobileAds.initialize(this){}
        val Activity_Amendment_SOR_BannerAdRequest = AdRequest.Builder().build()

        Activity_Amendment_SOR_BannerAd = findViewById(R.id.activity_amendment_sor_adView)
        Activity_Amendment_SOR_BannerAd.loadAd(Activity_Amendment_SOR_BannerAdRequest)

        val text : String?
        intent.extras.also {
            text = it?.getString("SORtext")
        }
        findViewById<TextView>(R.id.activity_amendment_sor_svtvtext).also {
            it.setText(Html.fromHtml(text, Html.FROM_HTML_MODE_LEGACY))
        }

    }
}