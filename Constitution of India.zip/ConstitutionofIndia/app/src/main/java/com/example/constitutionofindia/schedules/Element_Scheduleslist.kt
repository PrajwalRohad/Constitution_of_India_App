package com.example.constitutionofindia.schedules

data class Element_Scheduleslist(
    val ScheduleNum : String,
    val ScheduleName: String
)